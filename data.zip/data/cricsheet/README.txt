This zip archive contains data files from Cricsheet in YAML format. This
archive contains 96 recently played female matches.


The YAML data files contained in this zip file are version 0.91, and 0.92
files. You can learn about the structure of these files at
https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/recently_played_30_female.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2025-05-23 - international - T20 - female - 1448392 - West Indies vs England
2025-05-21 - international - T20 - female - 1448391 - West Indies vs England
2025-05-20 - international - T20 - female - 1485778 - Thailand vs Nepal
2025-05-20 - club - WOD - female - 1462374 - Somerset vs The Blaze
2025-05-19 - international - T20 - female - 1483779 - United Arab Emirates vs Nepal
2025-05-19 - club - WOD - female - 1462373 - Lancashire vs Durham
2025-05-19 - club - WOD - female - 1462372 - Warwickshire vs Hampshire
2025-05-19 - club - WOD - female - 1462371 - Surrey vs Essex
2025-05-18 - international - T20 - female - 1483778 - Thailand vs United Arab Emirates
2025-05-16 - international - T20 - female - 1483777 - Qatar vs Malaysia
2025-05-16 - international - T20 - female - 1483775 - Kuwait vs Bhutan
2025-05-15 - international - T20 - female - 1483773 - Bahrain vs Nepal
2025-05-15 - international - T20 - female - 1483772 - Thailand vs Bhutan
2025-05-15 - international - T20 - female - 1477677 - Bulgaria vs Estonia
2025-05-15 - international - T20 - female - 1477676 - Bulgaria vs Estonia
2025-05-14 - club - WOD - female - 1462370 - Lancashire vs Warwickshire
2025-05-14 - club - WOD - female - 1462369 - The Blaze vs Surrey
2025-05-14 - club - WOD - female - 1462368 - Essex vs Durham
2025-05-13 - international - T20 - female - 1483770 - Nepal vs Hong Kong
2025-05-13 - club - WOD - female - 1462367 - Hampshire vs Somerset
2025-05-12 - international - T20 - female - 1483767 - Bahrain vs Hong Kong
2025-05-12 - international - T20 - female - 1483766 - Kuwait vs Bhutan
2025-05-11 - international - T20 - female - 1483073 - Greece vs Germany
2025-05-11 - international - T20 - female - 1483072 - Germany vs Greece
2025-05-11 - international - ODI - female - 1476986 - India vs Sri Lanka
2025-05-11 - club - WOD - female - 1462366 - Surrey vs Somerset
2025-05-11 - club - WOD - female - 1462365 - The Blaze vs Lancashire
2025-05-11 - club - WOD - female - 1462364 - Hampshire vs Essex
2025-05-11 - club - WOD - female - 1462363 - Warwickshire vs Durham
2025-05-10 - international - T20 - female - 1483765 - United Arab Emirates vs Qatar
2025-05-10 - international - T20 - female - 1483763 - Bahrain vs Nepal
2025-05-10 - international - T20 - female - 1483071 - Germany vs Greece
2025-05-10 - international - T20 - female - 1483070 - Germany vs Greece
2025-05-09 - international - T20 - female - 1483762 - Malaysia vs United Arab Emirates
2025-05-09 - international - T20 - female - 1483760 - Kuwait vs Thailand
2025-05-09 - international - ODI - female - 1476985 - South Africa vs Sri Lanka
2025-05-07 - international - ODI - female - 1476984 - India vs South Africa
2025-05-07 - club - WOD - female - 1462362 - Somerset vs Warwickshire
2025-05-07 - club - WOD - female - 1462361 - Surrey vs Lancashire
2025-05-07 - club - WOD - female - 1462360 - Durham vs Hampshire
2025-05-06 - international - T20 - female - 1483759 - Thailand vs United Arab Emirates
2025-05-06 - international - T20 - female - 1483758 - Hong Kong vs Kuwait
2025-05-06 - club - WOD - female - 1462359 - Essex vs The Blaze
2025-05-05 - international - T20 - female - 1483943 - Bahrain vs Oman
2025-05-05 - international - T20 - female - 1483069 - Croatia vs Malta
2025-05-05 - international - T20 - female - 1483068 - Croatia vs Malta
2025-05-04 - international - T20 - female - 1483757 - United Arab Emirates vs Kuwait
2025-05-04 - international - T20 - female - 1483756 - Thailand vs Hong Kong
2025-05-04 - international - T20 - female - 1483067 - Czech Republic vs Cyprus
2025-05-04 - international - ODI - female - 1476983 - India vs Sri Lanka
2025-05-04 - club - WOD - female - 1462358 - Hampshire vs The Blaze
2025-05-04 - club - WOD - female - 1462357 - Surrey vs Warwickshire
2025-05-04 - club - WOD - female - 1462356 - Lancashire vs Essex
2025-05-04 - club - WOD - female - 1462355 - Durham vs Somerset
2025-05-03 - international - T20 - female - 1483942 - Oman vs Bahrain
2025-05-03 - international - T20 - female - 1483755 - Kuwait vs Thailand
2025-05-03 - international - T20 - female - 1483754 - United Arab Emirates vs Hong Kong
2025-05-03 - international - T20 - female - 1483066 - Czech Republic vs Cyprus
2025-05-03 - international - T20 - female - 1483065 - Czech Republic vs Cyprus
2025-05-03 - international - ODI - female - 1481713 - Zimbabwe vs United States of America
2025-05-02 - international - T20 - female - 1483941 - Bahrain vs Oman
2025-05-02 - international - T20 - female - 1483064 - Cyprus vs Czech Republic
2025-05-02 - international - T20 - female - 1483063 - Cyprus vs Czech Republic
2025-05-02 - international - ODI - female - 1476982 - South Africa vs Sri Lanka
2025-05-01 - international - ODI - female - 1481712 - Zimbabwe vs United States of America
2025-05-01 - club - WOD - female - 1462352 - Essex vs Somerset
2025-04-30 - international - T20 - female - 1477673 - Sierra Leone vs Botswana
2025-04-30 - international - T20 - female - 1477672 - Mozambique vs Eswatini
2025-04-30 - club - WOD - female - 1462354 - The Blaze vs Warwickshire
2025-04-30 - club - WOD - female - 1462353 - Surrey vs Durham
2025-04-30 - club - WOD - female - 1462351 - Lancashire vs Hampshire
2025-04-29 - international - T20 - female - 1481711 - Zimbabwe vs United States of America
2025-04-29 - international - T20 - female - 1477675 - Mozambique vs Eswatini
2025-04-29 - international - T20 - female - 1477674 - Botswana vs Sierra Leone
2025-04-29 - international - T20 - female - 1477666 - Mozambique vs Sierra Leone
2025-04-29 - international - T20 - female - 1477664 - Eswatini vs Botswana
2025-04-29 - international - ODI - female - 1476981 - India vs South Africa
2025-04-27 - international - T20 - female - 1481710 - Zimbabwe vs United States of America
2025-04-27 - international - T20 - female - 1477670 - Botswana vs Mozambique
2025-04-27 - international - T20 - female - 1477669 - Sierra Leone vs Eswatini
2025-04-27 - international - T20 - female - 1477668 - Sierra Leone vs Botswana
2025-04-27 - international - T20 - female - 1477667 - Mozambique vs Eswatini
2025-04-27 - international - ODI - female - 1476980 - Sri Lanka vs India
2025-04-27 - club - WOD - female - 1462350 - Somerset vs Lancashire
2025-04-27 - club - WOD - female - 1462349 - Hampshire vs Surrey
2025-04-27 - club - WOD - female - 1462348 - Warwickshire vs Essex
2025-04-27 - club - WOD - female - 1462347 - Durham vs The Blaze
2025-04-26 - international - T20 - female - 1477671 - Eswatini vs Sierra Leone
2025-04-26 - international - T20 - female - 1477665 - Botswana vs Mozambique
2025-04-26 - international - T20 - female - 1477663 - Mozambique vs Sierra Leone
2025-04-26 - international - T20 - female - 1477662 - Botswana vs Eswatini
2025-04-25 - international - T20 - female - 1481709 - Zimbabwe vs United States of America
2025-04-23 - club - WOD - female - 1462346 - Hampshire vs Warwickshire
2025-04-23 - club - WOD - female - 1462345 - The Blaze vs Lancashire
2025-04-23 - club - WOD - female - 1462344 - Surrey vs Somerset
2025-04-23 - club - WOD - female - 1462343 - Essex vs Durham
